"""
Legend Oracle - Backend Server
================================
Run karo:  python server.py
Phir browser mein:  http://localhost:8000

Requirements: pip install yfinance
"""

import http.server
import json
import urllib.parse
import os
import sys

# Try to import yfinance
try:
    import yfinance as yf
    HAS_YFINANCE = True
except ImportError:
    HAS_YFINANCE = False
    print("yfinance nahi mila. Install karo: pip install yfinance")

PORT = 8000
FRONTEND_FILE = "legend_oracle.html"

class Handler(http.server.SimpleHTTPRequestHandler):

    def log_message(self, format, *args):
        print(f"  [{self.address_string()}] {format % args}")

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        params = urllib.parse.parse_qs(parsed.query)

        # ── API endpoint ──
        if path == "/api/chart":
            symbol = params.get("symbol", ["AAPL"])[0]
            self.handle_chart(symbol)

        # ── Serve frontend HTML ──
        elif path == "/" or path == "/index.html":
            self.serve_file(FRONTEND_FILE)

        # ── Other static files ──
        else:
            super().do_GET()

    def handle_chart(self, symbol):
        if not HAS_YFINANCE:
            self.send_json({"error": "yfinance install karo: pip install yfinance"}, 500)
            return

        try:
            print(f"  Fetching: {symbol} ...")
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period="5y", interval="1wk")

            if hist.empty:
                self.send_json({"error": f"Data nahi mili: {symbol}"}, 404)
                return

            # Get ticker info
            try:
                info = ticker.fast_info
                name = getattr(info, 'long_name', symbol) or symbol
                currency = getattr(info, 'currency', '') or ''
            except:
                name = symbol
                currency = ''

            candles = []
            for dt, row in hist.iterrows():
                try:
                    ts = int(dt.timestamp())
                    candles.append({
                        "t": ts,
                        "date": dt.strftime("%Y-%m-%d"),
                        "o": round(float(row["Open"]), 6) if row["Open"] == row["Open"] else None,
                        "h": round(float(row["High"]), 6) if row["High"] == row["High"] else None,
                        "l": round(float(row["Low"]), 6) if row["Low"] == row["Low"] else None,
                        "c": round(float(row["Close"]), 6) if row["Close"] == row["Close"] else None,
                        "v": int(row["Volume"]) if row["Volume"] == row["Volume"] else 0,
                    })
                except:
                    continue

            # Filter valid candles
            candles = [c for c in candles if c["c"] and c["h"] and c["l"] and c["o"]]

            print(f"  OK: {len(candles)} candles for {symbol}")
            self.send_json({
                "symbol": symbol,
                "name": name,
                "currency": currency,
                "candles": candles
            })

        except Exception as e:
            print(f"  ERROR: {e}")
            self.send_json({"error": str(e)}, 500)

    def send_json(self, data, status=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def serve_file(self, filename):
        if not os.path.exists(filename):
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"legend_oracle.html not found - same folder mein rakhna")
            return
        with open(filename, "rb") as f:
            content = f.read()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)


def main():
    print("=" * 55)
    print("  LEGEND ORACLE — Backend Server")
    print("=" * 55)

    if not HAS_YFINANCE:
        print("\n  ERROR: yfinance nahi mila!")
        print("  Pehle yeh run karo:")
        print("    pip install yfinance")
        print("  Ya:")
        print("    pip install yfinance --break-system-packages")
        sys.exit(1)

    if not os.path.exists(FRONTEND_FILE):
        print(f"\n  WARNING: {FRONTEND_FILE} is folder mein nahi!")
        print(f"  legend_oracle.html aur server.py ek hi folder mein rakhna")

    print(f"\n  Server start ho raha hai...")
    print(f"  Browser mein kholo: http://localhost:{PORT}")
    print(f"  Band karo: Ctrl+C\n")

    try:
        server = http.server.HTTPServer(("localhost", PORT), Handler)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server band ho gaya.")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"\n  ERROR: Port {PORT} already use mein hai!")
            print(f"  Dusra port try karo: server.py mein PORT = 8001 kar do")
        else:
            raise


if __name__ == "__main__":
    main()
